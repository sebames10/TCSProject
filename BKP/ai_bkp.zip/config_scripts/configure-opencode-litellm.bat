@echo off
setlocal enabledelayedexpansion

set "LITELLM_BASE_URL=https://genailab.tcs.in"
set "MODELS_ENDPOINT=%LITELLM_BASE_URL%/v1/models"
set "API_KEY_FILE=%~dp0apikey.txt"
set "GLOBAL_CONFIG=%USERPROFILE%\.config\opencode\opencode.jsonc"
set "TEMP_JSON=%TEMP%\litellm_models.json"
set "TEMP_PS1=%TEMP%\opencode-write-config.ps1"

if not exist "%API_KEY_FILE%" (
    echo [FAIL] API key file not found: %API_KEY_FILE%
    goto :fail
)
for /f "usebackq tokens=*" %%A in ("%API_KEY_FILE%") do set "API_KEY=%%A"
if "!API_KEY!"=="" (
    echo [FAIL] API key file is empty: %API_KEY_FILE%
    goto :fail
)
echo [OK] API key loaded from %API_KEY_FILE%

echo [..] Fetching models from %MODELS_ENDPOINT%
curl -s -f -H "Authorization: Bearer !API_KEY!" -H "Content-Type: application/json" "%MODELS_ENDPOINT%" -o "%TEMP_JSON%"
if errorlevel 1 (
    echo [FAIL] Could not connect to %MODELS_ENDPOINT%
    goto :fail
)

if not exist "%USERPROFILE%\.config\opencode" mkdir "%USERPROFILE%\.config\opencode"
if exist "%GLOBAL_CONFIG%" (
    for /f %%D in ('powershell -NoProfile -Command "Get-Date -Format yyyy-MM-dd"') do set "DATESTAMP=%%D"
    copy /y "%GLOBAL_CONFIG%" "%USERPROFILE%\.config\opencode\!DATESTAMP!_opencode.jsonc.bak" >nul
    echo [OK] Backed up existing config
)

echo [..] Writing config to %GLOBAL_CONFIG%

:: Write temp PS1 that reads models JSON from stdin and generates config
> "%TEMP_PS1%" echo $ApiKey = $env:OPENCODE_API_KEY
>> "%TEMP_PS1%" echo $BaseURL = $env:OPENCODE_BASE_URL
>> "%TEMP_PS1%" echo $OutputPath = $env:OPENCODE_OUTPUT_PATH
>> "%TEMP_PS1%" echo $raw = [Console]::In.ReadToEnd()
>> "%TEMP_PS1%" echo $j = $raw ^| ConvertFrom-Json
>> "%TEMP_PS1%" echo $models = @($j.data ^| ForEach-Object { $_.id })
>> "%TEMP_PS1%" echo if ($models.Count -eq 0) { Write-Host '[FAIL] No models found.'; exit 1 }
>> "%TEMP_PS1%" echo Write-Host ('[OK] Found ' + $models.Count + ' model(s)')
>> "%TEMP_PS1%" echo $models ^| ForEach-Object { Write-Host ('     - ' + $_) }
>> "%TEMP_PS1%" echo $pm = [ordered]@{}
>> "%TEMP_PS1%" echo foreach ($m in $models) { $pm[$m] = [ordered]@{ id = $m; name = $m } }
>> "%TEMP_PS1%" echo $cfg = [ordered]@{
>> "%TEMP_PS1%" echo   '$schema' = 'https://opencode.ai/config.json'
>> "%TEMP_PS1%" echo   provider = [ordered]@{ litellm = [ordered]@{
>> "%TEMP_PS1%" echo     name = 'LiteLLM'
>> "%TEMP_PS1%" echo     options = [ordered]@{ apiKey = $ApiKey; baseURL = $BaseURL }
>> "%TEMP_PS1%" echo     models = $pm
>> "%TEMP_PS1%" echo   }}
>> "%TEMP_PS1%" echo   enabled_providers = @('litellm')
>> "%TEMP_PS1%" echo   model = 'litellm/' + $models[0]
>> "%TEMP_PS1%" echo }
>> "%TEMP_PS1%" echo $cfg ^| ConvertTo-Json -Depth 10 ^| Set-Content -Path $OutputPath -Encoding UTF8
>> "%TEMP_PS1%" echo Write-Host ('[OK] Default model: litellm/' + $models[0])

set "OPENCODE_API_KEY=!API_KEY!"
set "OPENCODE_BASE_URL=%LITELLM_BASE_URL%/v1"
set "OPENCODE_OUTPUT_PATH=%GLOBAL_CONFIG%"

powershell -NoProfile -ExecutionPolicy Bypass -File "%TEMP_PS1%" < "%TEMP_JSON%"
if errorlevel 1 (
    echo [FAIL] Failed to write config file.
    goto :fail
)

del "%TEMP_JSON%" 2>nul
del "%TEMP_PS1%" 2>nul
echo.
echo ============================================
echo   SUCCESS - opencode configured!
echo ============================================
echo.
echo   Config file:  %GLOBAL_CONFIG%
echo.
echo   Restart opencode for changes to take effect.
echo ============================================
echo.
pause
exit /b 0

:fail
del "%TEMP_JSON%" 2>nul
del "%TEMP_PS1%" 2>nul
echo.
echo ============================================
echo   FAILED - see errors above
echo ============================================
echo.
pause
exit /b 1
