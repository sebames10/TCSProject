@echo off
setlocal enabledelayedexpansion

set "LITELLM_BASE_URL=https://genailab.tcs.in"
set "MODELS_ENDPOINT=%LITELLM_BASE_URL%/v1/models"
set "API_KEY_FILE=%~dp0apikey.txt"
set "CONFIG_FILE=%APPDATA%\Code\User\chatLanguageModels.json"
set "TEMP_JSON=%TEMP%\litellm_models_copilot.json"
set "TEMP_PS1=%TEMP%\copilot-write-config.ps1"

if not exist "%API_KEY_FILE%" (
    echo [FAIL] API key file not found: %API_KEY_FILE%
    goto :fail
)
for /f "usebackq tokens=*" %%A in ("%API_KEY_FILE%") do set "API_KEY=%%A"
if "!API_KEY!"=="" (
    echo [FAIL] API key file is empty: %API_KEY_FILE%
    goto :fail
)
echo [OK] API key loaded from %API_KEY_FILE%

echo [..] Fetching models from %MODELS_ENDPOINT%
curl -s -f -H "Authorization: Bearer !API_KEY!" -H "Content-Type: application/json" "%MODELS_ENDPOINT%" -o "%TEMP_JSON%"
if errorlevel 1 (
    echo [FAIL] Could not connect to %MODELS_ENDPOINT%
    goto :fail
)

if exist "%CONFIG_FILE%" (
    for /f %%D in ('powershell -NoProfile -Command "Get-Date -Format yyyy-MM-dd"') do set "DATESTAMP=%%D"
    copy /y "%CONFIG_FILE%" "%APPDATA%\Code\User\!DATESTAMP!_chatLanguageModels.json.bak" >nul
    echo [OK] Backed up existing config
)

echo [..] Writing config to %CONFIG_FILE%

> "%TEMP_PS1%" echo $ApiKey = $env:COPILOT_API_KEY
>> "%TEMP_PS1%" echo $BaseUrl = $env:COPILOT_BASE_URL
>> "%TEMP_PS1%" echo $OutputPath = $env:COPILOT_OUTPUT_PATH
>> "%TEMP_PS1%" echo $raw = [Console]::In.ReadToEnd()
>> "%TEMP_PS1%" echo $j = $raw ^| ConvertFrom-Json
>> "%TEMP_PS1%" echo $excludePatterns = @('embedding', 'whisper')
>> "%TEMP_PS1%" echo $models = @($j.data ^| Where-Object {
>> "%TEMP_PS1%" echo     $id = $_.id
>> "%TEMP_PS1%" echo     $keep = $true
>> "%TEMP_PS1%" echo     foreach ($p in $excludePatterns) { if ($id -like "*$p*") { $keep = $false; break } }
>> "%TEMP_PS1%" echo     $keep
>> "%TEMP_PS1%" echo })
>> "%TEMP_PS1%" echo if ($models.Count -eq 0) { Write-Host '[FAIL] No chat models found.'; exit 1 }
>> "%TEMP_PS1%" echo Write-Host ('[OK] Found ' + $models.Count + ' chat model(s) (excluded embeddings and audio)')
>> "%TEMP_PS1%" echo $models ^| ForEach-Object { Write-Host ('     - ' + $_.id) }
>> "%TEMP_PS1%" echo $modelEntries = @($models ^| ForEach-Object {
>> "%TEMP_PS1%" echo     $id = $_.id
>> "%TEMP_PS1%" echo     $name = $id -replace '^azure_ai/', '' -replace '^azure/', '' -replace '^genailab-maas-', ''
>> "%TEMP_PS1%" echo     $name = $name -replace '[-_]', ' '
>> "%TEMP_PS1%" echo     $name = (Get-Culture).TextInfo.ToTitleCase($name.ToLower())
>> "%TEMP_PS1%" echo     $name = $name -replace '\bSonnet\b', 'Claude Sonnet' -replace '\bHaiku\b', 'Claude Haiku' -replace '\bOpus\b', 'Claude Opus'
>> "%TEMP_PS1%" echo     $name = $name -replace '\bGpt\b', 'GPT'
>> "%TEMP_PS1%" echo     $name = $name -replace '(\d)O', '$1o'
>> "%TEMP_PS1%" echo     $isAnthropic = $id -match 'sonnet' -or $id -match 'haiku' -or $id -match 'opus' -or $id -match 'claude'
>> "%TEMP_PS1%" echo     if ($isAnthropic) {
>> "%TEMP_PS1%" echo         $entry = [ordered]@{
>> "%TEMP_PS1%" echo             id             = $id
>> "%TEMP_PS1%" echo             name           = $name
>> "%TEMP_PS1%" echo             url            = "$BaseUrl/v1/messages"
>> "%TEMP_PS1%" echo             apiType        = 'messages'
>> "%TEMP_PS1%" echo             toolCalling    = $true
>> "%TEMP_PS1%" echo             vision         = $false
>> "%TEMP_PS1%" echo             requestHeaders = [ordered]@{ Authorization = "Bearer $ApiKey" }
>> "%TEMP_PS1%" echo         }
>> "%TEMP_PS1%" echo     } else {
>> "%TEMP_PS1%" echo         $entry = [ordered]@{
>> "%TEMP_PS1%" echo             id             = $id
>> "%TEMP_PS1%" echo             name           = $name
>> "%TEMP_PS1%" echo             url            = "$BaseUrl/v1/chat/completions"
>> "%TEMP_PS1%" echo             toolCalling    = $true
>> "%TEMP_PS1%" echo             vision         = $false
>> "%TEMP_PS1%" echo             requestHeaders = [ordered]@{ Authorization = "Bearer $ApiKey" }
>> "%TEMP_PS1%" echo         }
>> "%TEMP_PS1%" echo     }
>> "%TEMP_PS1%" echo     if ($_.PSObject.Properties['max_input_tokens']  -and $_.max_input_tokens)  { $entry['maxInputTokens']  = $_.max_input_tokens }
>> "%TEMP_PS1%" echo     if ($_.PSObject.Properties['max_output_tokens'] -and $_.max_output_tokens) { $entry['maxOutputTokens'] = $_.max_output_tokens }
>> "%TEMP_PS1%" echo     elseif ($isAnthropic) { $entry['maxInputTokens'] = 184000; $entry['maxOutputTokens'] = 16000 }
>> "%TEMP_PS1%" echo     $entry
>> "%TEMP_PS1%" echo })
>> "%TEMP_PS1%" echo $provider = @(
>> "%TEMP_PS1%" echo     [ordered]@{
>> "%TEMP_PS1%" echo         name   = 'GenAI Lab'
>> "%TEMP_PS1%" echo         vendor = 'customendpoint'
>> "%TEMP_PS1%" echo         models = $modelEntries
>> "%TEMP_PS1%" echo     }
>> "%TEMP_PS1%" echo )
>> "%TEMP_PS1%" echo $provider ^| ConvertTo-Json -Depth 6 ^| Set-Content -Path $OutputPath -Encoding UTF8

set "COPILOT_API_KEY=!API_KEY!"
set "COPILOT_BASE_URL=%LITELLM_BASE_URL%"
set "COPILOT_OUTPUT_PATH=%CONFIG_FILE%"

powershell -NoProfile -ExecutionPolicy Bypass -File "%TEMP_PS1%" < "%TEMP_JSON%"
if errorlevel 1 (
    echo [FAIL] Failed to write config file.
    goto :fail
)

del "%TEMP_JSON%" 2>nul
del "%TEMP_PS1%" 2>nul
echo.
echo ============================================
echo   SUCCESS - GitHub Copilot configured!
echo ============================================
echo.
echo   Config file:  %CONFIG_FILE%
echo.
echo   Reload VS Code for changes to take effect.
echo ============================================
echo.
pause
exit /b 0

:fail
del "%TEMP_JSON%" 2>nul
del "%TEMP_PS1%" 2>nul
echo.
echo ============================================
echo   FAILED - see errors above
echo ============================================
echo.
pause
exit /b 1
